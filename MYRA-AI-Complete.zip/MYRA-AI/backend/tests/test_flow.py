"""Full backend flow test WITHOUT needing fastapi installed (it is stubbed if missing).
Run:  python tests/test_flow.py
Covers: provider fallback (fail -> slow -> ok), chat streaming, website build -> files on disk -> preview message,
all-providers-failed error, and that every message type is one the Android app understands."""
import asyncio, os, sys, tempfile, types

os.environ["MYRA_TOKEN"] = "test-token"
os.environ["PROJECTS_DIR"] = tempfile.mkdtemp()
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

try:
    import fastapi  # noqa: F401
except ImportError:
    fa = types.ModuleType("fastapi")

    class _App:
        def __init__(self, *a, **k): pass
        def get(self, *a, **k): return lambda f: f
        def websocket(self, *a, **k): return lambda f: f

    fa.FastAPI, fa.HTTPException, fa.WebSocket = _App, Exception, object
    fa.WebSocketDisconnect = type("WebSocketDisconnect", (Exception,), {})
    resp = types.ModuleType("fastapi.responses")
    resp.FileResponse = object
    sys.modules["fastapi"], sys.modules["fastapi.responses"] = fa, resp

import main

ANDROID_UNDERSTANDS = {"mode", "log", "token", "code_chunk", "file_done", "preview", "done", "error"}


class Fake:
    def __init__(self, name, mode):
        self.name, self.mode, self.available = name, mode, True

    async def stream(self, system, messages, max_tokens):
        if self.mode == "fail":
            raise RuntimeError("boom")
        if self.mode == "slow":
            await asyncio.sleep(30)
        build = system.startswith("You are MYRA's build engine")
        text = ("===FILE: index.html===\n<h1>Hello MYRA</h1>\n===END===\n"
                "===FILE: style.css===\nbody{background:#0A0A0C}\n===END===\n") if build else "Haan Boss, bol do."
        for i in range(0, len(text), 7):
            yield text[i:i + 7]


async def ask(modes, text):
    main.PROVIDERS = {n: Fake(n, m) for n, m in modes}
    main.config.CHAT_CHAIN = main.config.CODE_CHAIN = [n for n, _ in modes]
    main.config.FIRST_TOKEN_TIMEOUT = 0.4
    out = []

    async def send(obj):
        out.append(obj)

    await main.run_ask(send, "id1", text, "session-1")
    return out


def check_types(msgs):
    for m in msgs:
        assert m["type"] in ANDROID_UNDERSTANDS, "Android app does not handle: " + m["type"]


def test_chat_fallback():
    msgs = asyncio.run(ask([("a", "fail"), ("b", "slow"), ("c", "ok")], "kaise ho"))
    check_types(msgs)
    assert "".join(m["text"] for m in msgs if m["type"] == "token") == "Haan Boss, bol do."
    assert msgs[-1]["type"] == "done"
    assert any(m["type"] == "log" and m["text"].startswith("a:") for m in msgs)


def test_website_build():
    msgs = asyncio.run(ask([("a", "ok")], "ek portfolio website banao"))
    check_types(msgs)
    types_ = [m["type"] for m in msgs]
    assert msgs[0] == {"type": "mode", "id": "id1", "mode": "code"}
    assert types_.count("file_done") == 2 and "preview" in types_ and types_[-1] == "done"
    url = next(m["url"] for m in msgs if m["type"] == "preview")
    pid = url.split("/")[2]
    page = os.path.join(os.environ["PROJECTS_DIR"], pid, "index.html")
    assert "<h1>Hello MYRA</h1>" in open(page).read()
    assert os.path.exists(os.path.join(os.environ["PROJECTS_DIR"], pid, "style.css"))


def test_all_fail():
    msgs = asyncio.run(ask([("a", "fail")], "hello"))
    check_types(msgs)
    assert msgs[-1]["type"] == "error"


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("ok", name)
