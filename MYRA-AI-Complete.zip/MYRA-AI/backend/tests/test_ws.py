"""End-to-end WebSocket test with fake providers. Needs: pip install fastapi httpx (and the rest of requirements)."""
import os, sys
os.environ["MYRA_TOKEN"] = "test-token"
os.environ["PROJECTS_DIR"] = "/tmp/myra_test_projects"
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import asyncio
from fastapi.testclient import TestClient
import main


class Fake:
    def __init__(self, name, mode):
        self.name, self.mode, self.available = name, mode, True

    async def stream(self, system, messages, max_tokens):
        if self.mode == "fail":
            raise RuntimeError("boom")
        if self.mode == "slow":
            await asyncio.sleep(30)
        text = (
            "===FILE: index.html===\n<h1>Hello</h1>\n===END===\n"
            if system.startswith("You are MYRA's build engine")
            else "Haan Boss, bol do."
        )
        for i in range(0, len(text), 5):
            yield text[i:i + 5]


def run(chain_modes):
    main.PROVIDERS = {n: Fake(n, m) for n, m in chain_modes}
    main.config.CHAT_CHAIN = main.config.CODE_CHAIN = [n for n, _ in chain_modes]
    main.config.FIRST_TOKEN_TIMEOUT = 0.5
    out = []
    with TestClient(main.app) as c, c.websocket_connect("/ws") as ws:
        ws.send_json({"type": "auth", "token": "test-token", "session": "s1"})
        assert ws.receive_json()["type"] == "ready"
        return ws, c, out


def collect(modes, text):
    main.PROVIDERS = {n: Fake(n, m) for n, m in modes}
    main.config.CHAT_CHAIN = main.config.CODE_CHAIN = [n for n, _ in modes]
    main.config.FIRST_TOKEN_TIMEOUT = 0.5
    msgs = []
    with TestClient(main.app) as c:
        with c.websocket_connect("/ws") as ws:
            ws.send_json({"type": "auth", "token": "test-token", "session": "s1"})
            assert ws.receive_json()["type"] == "ready"
            ws.send_json({"type": "ask", "id": "a1", "text": text})
            while True:
                m = ws.receive_json()
                msgs.append(m)
                if m["type"] in ("done", "error"):
                    break
        if any(m["type"] == "preview" for m in msgs):
            url = next(m["url"] for m in msgs if m["type"] == "preview")
            r = c.get(url)
            assert r.status_code == 200 and "<h1>Hello</h1>" in r.text
            assert "sandbox" in r.headers["content-security-policy"]
            assert c.get(url.replace("index.html", "../../etc/passwd")).status_code in (404, 400)
    return msgs


def test_auth_rejected():
    with TestClient(main.app) as c, c.websocket_connect("/ws") as ws:
        ws.send_json({"type": "auth", "token": "wrong"})
        assert ws.receive_json()["message"] == "unauthorized"


def test_chat_falls_back_from_failing_and_slow_providers():
    msgs = collect([("a", "fail"), ("b", "slow"), ("c", "ok")], "kaise ho")
    assert "".join(m["text"] for m in msgs if m["type"] == "token") == "Haan Boss, bol do."
    assert msgs[-1]["type"] == "done"
    assert any("a:" in m.get("text", "") for m in msgs if m["type"] == "log")


def test_all_fail_reports_error():
    assert collect([("a", "fail")], "hello")[-1]["type"] == "error"


def test_code_build_and_preview():
    msgs = collect([("a", "ok")], "ek portfolio website banao")
    types = [m["type"] for m in msgs]
    assert "code_chunk" in types and "file_done" in types and "preview" in types and types[-1] == "done"


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("ok", name)
