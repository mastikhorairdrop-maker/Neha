"""MYRA backend: one WebSocket (/ws) for chat + code generation, plus /preview for generated sites.

Protocol (JSON text frames)
  client -> server: {"type":"auth","token":"..","session":"..","v":1}   (first frame, within 5 s)
                    {"type":"ask","id":"..","text":".."}                  chat or website build (auto-detected)
                    {"type":"cancel","id":".."} | {"type":"ping"}
  server -> client: {"type":"ready","providers":[..]}
                    {"type":"mode","id","mode":"chat"|"code"}
                    {"type":"log","id","text"}        {"type":"token","id","text"}
                    {"type":"code_chunk","id","file","text"}   {"type":"file_done","id","file","bytes"}
                    {"type":"preview","id","url"}     {"type":"done","id"}
                    {"type":"error","id","message"}   {"type":"pong"}
"""
import asyncio
import hmac
import json
import logging
import re
import shutil
import time
import uuid
from collections import OrderedDict
from contextlib import asynccontextmanager, suppress
from pathlib import Path

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse

import config
from codegen import (
    CODEGEN_SYSTEM,
    CodegenError,
    FileStreamParser,
    looks_like_build_request,
    strip_fences,
)
from orchestrator import AllProvidersFailed, stream_chain
from providers import build_providers

log = logging.getLogger("myra")
logging.basicConfig(level=logging.INFO)

PROVIDERS = build_providers()
PROJECTS = Path(config.PROJECTS_DIR).resolve()
SESSIONS: "OrderedDict[str, list[dict]]" = OrderedDict()

PERSONA = """You are MYRA, the user's personal voice-native AI assistant. The user is "Boss".
Personality: highly intelligent, sharp, confident, witty, slightly sarcastic, fiercely loyal to Boss.
Language: natural Hinglish (Hindi and English mixed, written in Roman script) with a local cultural rhythm. If Boss writes pure English or Devanagari Hindi, answer in that language instead.
Voice rules: your reply is spoken aloud. Keep it to one to three short sentences unless Boss asks for detail. No markdown, no bullet points, no emojis, no code blocks, never read out URLs.
Be honest: if you do not know, say so. Sarcasm is playful, never cruel or demeaning to Boss.
Never claim a phone action (call, message, lock) was done; those are handled separately on the device."""


def prune_projects() -> None:
    cutoff = time.time() - config.PROJECT_TTL_DAYS * 86400
    for d in PROJECTS.iterdir():
        with suppress(Exception):
            if d.is_dir() and d.stat().st_mtime < cutoff:
                shutil.rmtree(d, ignore_errors=True)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    if not config.TOKEN:
        raise RuntimeError("MYRA_TOKEN is not set; refusing to start without authentication")
    PROJECTS.mkdir(parents=True, exist_ok=True)
    prune_projects()
    live = [n for n, p in PROVIDERS.items() if p.available]
    log.info("providers available: %s", live or "NONE (add API keys)")
    yield


app = FastAPI(title="MYRA backend", lifespan=lifespan)


@app.get("/health")
async def health():
    return {"ok": True, "providers": [n for n, p in PROVIDERS.items() if p.available]}


@app.get("/preview/{pid}/{path:path}")
async def preview(pid: str, path: str = ""):
    if not re.fullmatch(r"[a-f0-9]{12}", pid):
        raise HTTPException(404)
    root = (PROJECTS / pid).resolve()
    target = (root / (path or "index.html")).resolve()
    if not target.is_relative_to(root) or not target.is_file():
        raise HTTPException(404)
    return FileResponse(
        target,
        headers={
            "Content-Security-Policy": "sandbox allow-scripts allow-forms allow-popups allow-modals",
            "Cache-Control": "no-store",
            "X-Content-Type-Options": "nosniff",
        },
    )


# --------------------------------------------------------------------------- tasks

async def run_chat(send, mid: str, text: str, session: str) -> None:
    hist = SESSIONS.setdefault(session, [])
    SESSIONS.move_to_end(session)
    while len(SESSIONS) > 200:
        SESSIONS.popitem(last=False)

    messages = hist[-12:] + [{"role": "user", "content": text}]
    parts: list[str] = []

    async def lg(m: str):
        await send({"type": "log", "id": mid, "text": m})

    async for ev in stream_chain(
        config.CHAT_CHAIN, PROVIDERS, PERSONA, messages, 400, config.FIRST_TOKEN_TIMEOUT, lg
    ):
        if ev[0] == "provider":
            await lg(f"{ev[1]} first token {ev[2]:.0f} ms")
        else:
            parts.append(ev[1])
            await send({"type": "token", "id": mid, "text": ev[1]})

    hist.append({"role": "user", "content": text})
    hist.append({"role": "assistant", "content": "".join(parts)})
    del hist[:-24]


async def write_project_file(pid: str, name: str, text: str) -> int:
    root = (PROJECTS / pid).resolve()
    target = (root / name).resolve()
    if not target.is_relative_to(root):
        raise CodegenError("bad file path")
    data = strip_fences(text).encode("utf-8")

    def _write():
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)

    await asyncio.to_thread(_write)
    return len(data)


async def run_code(send, mid: str, text: str) -> None:
    pid = uuid.uuid4().hex[:12]
    parser = FileStreamParser()
    files: dict[str, list[str]] = {}
    written: list[str] = []

    async def lg(m: str):
        await send({"type": "log", "id": mid, "text": m})

    async def handle(ev: tuple):
        kind = ev[0]
        if kind == "start":
            files[ev[1]] = []
            await lg(f"writing {ev[1]}")
        elif kind == "chunk":
            files[ev[1]].append(ev[2])
            await send({"type": "code_chunk", "id": mid, "file": ev[1], "text": ev[2]})
        elif kind == "done":
            size = await write_project_file(pid, ev[1], "".join(files.pop(ev[1], [])))
            written.append(ev[1])
            await send({"type": "file_done", "id": mid, "file": ev[1], "bytes": size})

    await lg("build engine: starting")
    async for ev in stream_chain(
        config.CODE_CHAIN,
        PROVIDERS,
        CODEGEN_SYSTEM,
        [{"role": "user", "content": text}],
        config.CODE_MAX_TOKENS,
        config.FIRST_TOKEN_TIMEOUT * 2,
        lg,
    ):
        if ev[0] == "provider":
            await lg(f"{ev[1]} first token {ev[2]:.0f} ms")
        else:
            for pe in parser.feed(ev[1]):
                await handle(pe)
    for pe in parser.finish():
        await handle(pe)

    if "index.html" not in written:
        raise CodegenError("model did not produce index.html")
    await send({"type": "preview", "id": mid, "url": f"/preview/{pid}/index.html"})


async def run_ask(send, mid: str, text: str, session: str) -> None:
    async def safe_send(obj: dict):
        with suppress(Exception):
            await send(obj)

    try:
        if looks_like_build_request(text):
            await send({"type": "mode", "id": mid, "mode": "code"})
            await run_code(send, mid, text)
        else:
            await send({"type": "mode", "id": mid, "mode": "chat"})
            await run_chat(send, mid, text, session)
        await send({"type": "done", "id": mid})
    except asyncio.CancelledError:
        raise
    except AllProvidersFailed:
        await safe_send({"type": "error", "id": mid, "message": "Saare AI models abhi unavailable hain."})
    except CodegenError as e:
        await safe_send({"type": "error", "id": mid, "message": f"Build fail: {e}"})
    except Exception:
        log.exception("ask failed")
        await safe_send({"type": "error", "id": mid, "message": "Server mein dikkat aayi."})


# --------------------------------------------------------------------------- websocket

@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws.accept()
    lock = asyncio.Lock()

    async def send(obj: dict) -> None:
        async with lock:
            await ws.send_text(json.dumps(obj, ensure_ascii=False))

    try:
        auth = json.loads(await asyncio.wait_for(ws.receive_text(), timeout=5))
        supplied = str(auth.get("token", "")).encode()
        if auth.get("type") != "auth" or not hmac.compare_digest(supplied, config.TOKEN.encode()):
            await send({"type": "error", "id": "", "message": "unauthorized"})
            await ws.close(code=4401)
            return
    except (asyncio.TimeoutError, ValueError, WebSocketDisconnect, AttributeError):
        with suppress(Exception):
            await ws.close(code=4400)
        return

    session = str(auth.get("session") or uuid.uuid4().hex)[:64]
    await send({"type": "ready", "providers": [n for n, p in PROVIDERS.items() if p.available]})

    tasks: dict[str, asyncio.Task] = {}
    try:
        while True:
            raw = await ws.receive_text()
            if len(raw) > config.MAX_MESSAGE_CHARS:
                continue
            try:
                msg = json.loads(raw)
            except ValueError:
                continue
            kind = msg.get("type")
            mid = str(msg.get("id", ""))[:32]

            if kind == "ask":
                text = str(msg.get("text", "")).strip()[:4000]
                if not text or not mid or mid in tasks:
                    continue
                if len(tasks) >= config.MAX_TASKS_PER_CONNECTION:
                    await send({"type": "error", "id": mid, "message": "Ek saath bahut saare kaam, Boss."})
                    continue
                task = asyncio.create_task(run_ask(send, mid, text, session))
                tasks[mid] = task
                task.add_done_callback(lambda _t, k=mid: tasks.pop(k, None))
            elif kind == "cancel":
                t = tasks.pop(mid, None)
                if t:
                    t.cancel()
            elif kind == "ping":
                await send({"type": "pong"})
    except WebSocketDisconnect:
        pass
    except Exception:
        log.exception("websocket loop")
    finally:
        for t in list(tasks.values()):
            t.cancel()
