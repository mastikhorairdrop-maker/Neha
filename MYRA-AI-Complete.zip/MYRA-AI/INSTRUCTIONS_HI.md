# MYRA AI — COMPLETE (Stage 1 + 2 + 3, ek hi project)

Is ek ZIP mein sab kuch hai. Alag-alag stage ki files ab lagane ki zaroorat nahi.

| Folder / file | Kya hai |
|---|---|
| `app/` | Android app: neon orb UI, voice, torch/battery/volume/alarm, call/SMS/WhatsApp, screen automation, "Okay Myra" wake word, WebSocket, website preview |
| `backend/` | FastAPI server: multi-model fallback (Groq / Claude / OpenAI / Gemini), streaming, website builder |
| `.github/workflows/android.yml` | GitHub par APK banane wala workflow |
| `gradle.properties` | Server ka URL aur token yahin likhna hai |

## A. GitHub par APK banana (sirf app, server ke bina bhi chalega)
1. ZIP ko extract karo. Andar `MYRA-AI` folder milega.
2. Us folder ke **andar ki saari cheezein** (`app`, `backend`, `.github`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties` ...) GitHub repo mein upload karo. `settings.gradle.kts` repo mein sabse upar dikhni chahiye.
3. `.github` hidden folder hai, upload mein chhoot sakta hai. Chhoote to GitHub mein **Add file → Create new file** kholo, naam likho `.github/workflows/android.yml` aur ye paste karo:

```yaml
name: Build MYRA APK
on:
  push:
    branches: [ main, master ]
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Locate project folder
        id: loc
        run: |
          FILE=$(find . -maxdepth 3 -name settings.gradle.kts | head -n 1)
          if [ -z "$FILE" ]; then echo "settings.gradle.kts not found"; exit 1; fi
          echo "dir=$(dirname "$FILE")" >> "$GITHUB_OUTPUT"
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17
      - uses: android-actions/setup-android@v3
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: 8.9
      - name: Build debug APK
        working-directory: ${{ steps.loc.outputs.dir }}
        run: gradle assembleDebug --stacktrace
      - uses: actions/upload-artifact@v4
        with:
          name: myra-debug-apk
          path: ${{ steps.loc.outputs.dir }}/app/build/outputs/apk/debug/*.apk
```
4. **Actions** tab → **Build MYRA APK** → **Run workflow**.
5. Hara ✓ aaye to us run ko kholo → neeche **Artifacts** → `myra-debug-apk` download karo → phone mein install (Unknown sources allow).

## B. Phone par pehli baar
- **Hands-free: say "Okay Myra"** switch on karo → Mic aur Notification permission do.
- Orb par tap karke bhi bol sakte ho.
- "lock kar do" bolo → Device Admin mein **Activate**.
- "screen padho" bolo → Accessibility mein *MYRA Screen Automation* on karo. Android 13+ par pehle App info → ⋮ → **Allow restricted settings**.
- Call, SMS, Contacts permission pehli baar use karne par poochhi jaati hai.

Try karo: "torch on karo", "battery kitni hai", "7 baje ka alarm", "Rahul ko whatsapp karo ki main late hoon", "ek dark portfolio website banao".

## C. Server (optional, AI jawab + website builder ke liye)
Bina server ke local commands (torch, call, alarm, WhatsApp...) chalte rahenge. Smart jawab aur website builder ke liye server chahiye:
```bash
cd backend
pip install -r requirements.txt
cp .env.example .env     # MYRA_TOKEN aur kam se kam ek API key daalo
uvicorn main:app --host 0.0.0.0 --port 8000
```
Phir `gradle.properties` mein `MYRA_BACKEND_URL` aur `MYRA_TOKEN` (same value jo `.env` mein hai) daalo, aur app dobara build karo. Emulator ke liye `ws://10.0.2.2:8000/ws`, real phone ke liye `ws://<PC-ka-IP>:8000/ws`, deploy kiya ho to `wss://tumhara-domain/ws`.
Server check: `python tests/test_flow.py` (FastAPI ke bina bhi chalta hai).

## D. Agar GitHub build fail ho
Mai yahan compiler nahi chala sakta, isliye asli log hi final saboot hai. Actions → fail hua run → **Build debug APK** step → `e: file:///...` se shuru hone wali laal lines copy karke mujhe bhejo. Mai usi line ko theek kar dunga.

## E. Sach-sach
- Ye project mere paas compile nahi hua. Maine har file padhi, imports/resources/bindings script se check kiye, aur backend ke 9 tests chalaye (sab pass).
- "Okay Myra" Android ke speech recognizer par chalta hai, isliye battery lagti hai. Reboot ke baad app ek baar kholna padega.
- AI model names badalte rehte hain; `.env` mein `CLAUDE_MODEL`, `GROQ_MODEL` etc. check karo.
