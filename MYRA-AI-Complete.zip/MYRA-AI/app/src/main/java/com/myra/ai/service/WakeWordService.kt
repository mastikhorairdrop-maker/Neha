package com.myra.ai.service

import android.Manifest
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.myra.ai.MainActivity
import com.myra.ai.MyraApp
import com.myra.ai.R
import com.myra.ai.core.CrashLog
import com.myra.ai.core.Kind
import com.myra.ai.core.MyraConfig
import com.myra.ai.core.MyraEngine
import com.myra.ai.core.Safe
import com.myra.ai.core.WakeMatcher
import com.myra.ai.ui.OrbView
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.min

/**
 * Hands-free "Okay Myra".
 * Owns the one SpeechRecognizer while running:  WAKE (listen for the phrase) → COMMAND (capture the request)
 * → PAUSED (engine is thinking / talking, so MYRA never hears herself) → back to WAKE.
 * Self-healing: recognizer errors back off and restart, a watchdog revives a stalled recognizer.
 */
class WakeWordService : Service() {

    companion object {
        const val ACTION_STOP = "com.myra.ai.WAKE_STOP"
        const val ACTION_TALK = "com.myra.ai.WAKE_TALK"
        private const val CHANNEL_ID = "myra_wake"
        private const val NOTIF_ID = 42

        @Volatile
        var running = false
            private set

        fun start(ctx: Context): Boolean = Safe.call("wake.start", false) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, WakeWordService::class.java))
            true
        }

        fun stop(ctx: Context) = Safe.exec("wake.stop") { ctx.stopService(Intent(ctx, WakeWordService::class.java)) }

        /** Push-to-talk from the UI while the service owns the microphone. */
        fun talk(ctx: Context) = Safe.exec("wake.talk") {
            ctx.startService(Intent(ctx, WakeWordService::class.java).setAction(ACTION_TALK))
        }
    }

    private enum class Mode { WAKE, COMMAND, PAUSED }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(
        SupervisorJob() + Dispatchers.Main.immediate + CoroutineExceptionHandler { _, t -> CrashLog.write("wake.scope", t) }
    )
    private lateinit var engine: MyraEngine

    private var recognizer: SpeechRecognizer? = null
    private var onDevice = false
    private var mode = Mode.PAUSED
    private var awaitingEngine = false
    private var failures = 0
    private var lastActivity = 0L
    private var pausedSince = 0L
    private var ackBeeped = false
    private var pendingRemainder = ""
    private var wakeLock: PowerManager.WakeLock? = null

    private val restart = Runnable { Safe.exec("wake.restart") { beginListening() } }
    private val stable = Runnable { Safe.exec("wake.stable") { if (mode == Mode.WAKE) onWake(pendingRemainder) } }
    private val watchdog = object : Runnable {
        override fun run() {
            Safe.exec("wake.watchdog") { checkHealth() }
            main.postDelayed(this, 10_000)
        }
    }

    // ------------------------------------------------------------------ service lifecycle

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        engine = (application as MyraApp).engine
        onDevice = Build.VERSION.SDK_INT >= 33 && Safe.call("wake.ondevice", false) {
            SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TALK -> {
                if (running) Safe.exec("wake.ptt") { pushToTalk() } else stopSelf()
                return if (running) START_STICKY else START_NOT_STICKY
            }
        }
        if (!running) {
            if (!enterForeground()) {
                stopSelf()
                return START_NOT_STICKY
            }
            running = true
            acquireWakeLock()
            engine.wakeState(true)
            scope.launch {
                engine.busy.collect { b ->
                    if (!b && awaitingEngine) {
                        awaitingEngine = false
                        resumeWake()
                    }
                }
            }
            main.postDelayed(watchdog, 10_000)
            resumeWake()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        Safe.exec("wake.destroy") {
            main.removeCallbacksAndMessages(null)
            scope.cancel()
            resetRecognizer()
            if (wakeLock?.isHeld == true) wakeLock?.release()
            engine.wakeState(false)
            engine.orb(OrbView.State.IDLE)
        }
        super.onDestroy()
    }

    private fun enterForeground(): Boolean = try {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            engine.line(Kind.ERR, "WAKE", "Mic permission chahiye hands-free ke liye.")
            false
        } else {
            NotificationManagerCompat.from(this).createNotificationChannel(
                NotificationChannelCompat.Builder(CHANNEL_ID, NotificationManagerCompat.IMPORTANCE_LOW)
                    .setName("MYRA hands-free").build()
            )
            ServiceCompat.startForeground(
                this, NOTIF_ID, buildNotification(),
                if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
            )
            true
        }
    } catch (t: Throwable) {
        // SecurityException / ForegroundServiceStartNotAllowedException (e.g. started from background on Android 12+/14+)
        CrashLog.write("wake.foreground", t)
        engine.line(Kind.ERR, "WAKE", "Hands-free start nahi hua: app khol ke dobara toggle karo.")
        false
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WakeWordService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("MYRA is listening")
            .setContentText("Say “Okay Myra”")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun acquireWakeLock() = Safe.exec("wake.lock") {
        val pm = (getSystemService(PowerManager::class.java) as PowerManager)
        wakeLock = (wakeLock ?: pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "myra:wake").apply { setReferenceCounted(false) })
            .also { it.acquire(6 * 60 * 60 * 1000L) }
    }

    // ------------------------------------------------------------------ state machine

    private fun setMode(m: Mode) {
        mode = m
        if (m == Mode.PAUSED) pausedSince = SystemClock.uptimeMillis()
    }

    private fun resumeWake() {
        setMode(Mode.WAKE)
        scheduleRestart(300)
    }

    private fun scheduleRestart(delayMs: Long) {
        main.removeCallbacks(restart)
        main.postDelayed(restart, delayMs)
    }

    private fun backoff(): Long {
        failures++
        return min(8_000L, 300L shl min(failures, 5))
    }

    private fun checkHealth() {
        if (wakeLock?.isHeld == false) acquireWakeLock()
        val now = SystemClock.uptimeMillis()
        if (mode == Mode.PAUSED) {
            if (!engine.busy.value && now - pausedSince > 6_000) {
                awaitingEngine = false
                resumeWake()
            }
        } else if (now - lastActivity > 30_000) {
            resetRecognizer()
            beginListening()
        }
    }

    private fun ensureRecognizer(): SpeechRecognizer? = Safe.call<SpeechRecognizer?>("wake.recognizer", null) {
        recognizer ?: (if (Build.VERSION.SDK_INT >= 33 && onDevice) SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        else SpeechRecognizer.createSpeechRecognizer(this)).also {
            it.setRecognitionListener(listener)
            recognizer = it
        }
    }

    private fun resetRecognizer() {
        Safe.exec("wake.reset") { recognizer?.destroy() }
        recognizer = null
    }

    private fun beginListening() {
        if (!running || mode == Mode.PAUSED) return
        val r = ensureRecognizer()
        if (r == null) {
            scheduleRestart(backoff())
            return
        }
        try {
            r.cancel()
            ackBeeped = false
            lastActivity = SystemClock.uptimeMillis()
            r.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, MyraConfig.SPEECH_LANG)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                }
            )
        } catch (t: Throwable) {
            CrashLog.write("wake.begin", t)
            resetRecognizer()
            scheduleRestart(backoff())
        }
    }

    private fun onWake(remainder: String) {
        if (mode != Mode.WAKE) return
        setMode(Mode.PAUSED)
        main.removeCallbacks(restart)
        main.removeCallbacks(stable)
        Safe.exec("wake.cancel") { recognizer?.cancel() }
        if (!ackBeeped) beep()
        engine.onWake()
        if (remainder.length >= 2) handOff(remainder) else main.postDelayed({ Safe.exec("wake.cmd") { enterCommandMode() } }, 250)
    }

    private fun enterCommandMode() {
        if (!running) return
        setMode(Mode.COMMAND)
        engine.orb(OrbView.State.LISTENING)
        beginListening()
    }

    private fun handOff(text: String) {
        setMode(Mode.PAUSED)
        awaitingEngine = true
        engine.handleUtterance(text)
    }

    private fun toWake() {
        engine.orb(OrbView.State.IDLE)
        resumeWake()
    }

    private fun pushToTalk() {
        main.removeCallbacks(restart)
        main.removeCallbacks(stable)
        if (engine.busy.value) engine.interrupt()
        awaitingEngine = false
        Safe.exec("wake.ptt.cancel") { recognizer?.cancel() }
        beep()
        setMode(Mode.COMMAND)
        engine.orb(OrbView.State.LISTENING)
        main.postDelayed({ Safe.exec("wake.ptt.begin") { beginListening() } }, 250)
    }

    private fun beep() = Safe.exec("wake.beep") {
        val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 60)
        tg.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
        main.postDelayed({ Safe.exec("wake.beep.release") { tg.release() } }, 400)
    }

    // ------------------------------------------------------------------ recognizer callbacks

    private fun firstResult(b: Bundle?): String? =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            lastActivity = SystemClock.uptimeMillis()
            failures = 0
        }

        override fun onBeginningOfSpeech() {
            lastActivity = SystemClock.uptimeMillis()
        }

        override fun onRmsChanged(rmsdB: Float) {
            lastActivity = SystemClock.uptimeMillis()
            if (mode == Mode.COMMAND) engine.level(((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
        }

        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            Safe.exec("wake.partial") {
                val t = firstResult(partialResults)
                if (t != null) {
                    when (mode) {
                        Mode.WAKE -> WakeMatcher.find(t)?.let { rem ->
                            if (!ackBeeped) {
                                ackBeeped = true
                                beep()
                            }
                            pendingRemainder = rem
                            main.removeCallbacks(stable)
                            main.postDelayed(stable, 900)   // fire once the phrase has stopped changing
                        }
                        Mode.COMMAND -> engine.hint(t)
                        Mode.PAUSED -> {}
                    }
                }
            }
        }

        override fun onResults(results: Bundle?) {
            Safe.exec("wake.results") {
                val t = firstResult(results)
                when (mode) {
                    Mode.WAKE -> {
                        val rem = t?.let { WakeMatcher.find(it) }
                        if (rem != null) onWake(rem) else scheduleRestart(120)
                    }
                    Mode.COMMAND -> if (t.isNullOrBlank()) toWake() else handOff(t)
                    Mode.PAUSED -> {}
                }
            }
        }

        override fun onError(error: Int) {
            Safe.exec("wake.error") {
                if (mode == Mode.PAUSED) return@exec
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        if (mode == Mode.COMMAND) toWake() else scheduleRestart(100)
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                        engine.line(Kind.ERR, "WAKE", "Mic permission gayab ho gayi. Hands-free band.")
                        stopSelf()
                    }
                    12, 13 -> {   // LANGUAGE_NOT_SUPPORTED / LANGUAGE_UNAVAILABLE: drop on-device model, use the normal recognizer
                        onDevice = false
                        resetRecognizer()
                        scheduleRestart(300)
                    }
                    else -> {
                        resetRecognizer()
                        if (mode == Mode.COMMAND) setMode(Mode.WAKE)
                        scheduleRestart(backoff())
                    }
                }
            }
        }
    }
}
