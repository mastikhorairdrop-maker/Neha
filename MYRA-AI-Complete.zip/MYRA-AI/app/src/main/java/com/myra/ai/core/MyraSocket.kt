package com.myra.ai.core

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import kotlin.math.min
import kotlin.random.Random

class ServerMsg(val type: String, val id: String, val json: JSONObject) {
    fun str(key: String): String = json.optString(key, "")
    fun int(key: String): Int = json.optInt(key, 0)
}

/**
 * One persistent WebSocket to the MYRA backend.
 * - Auto-reconnect with exponential backoff + jitter (also on network change via [reconnectNow]).
 * - Replies are routed to per-request channels so a slow consumer never blocks the socket thread.
 * - Every callback is wrapped: a bad frame can't take the app down.
 */
class MyraSocket(
    private val url: String,
    private val token: String,
    private val session: String,
    private val scope: CoroutineScope,
    private val onProblem: (String) -> Unit,
    private val onState: (Boolean) -> Unit
) {
    private val client = OkHttpClient.Builder()
        .pingInterval(15, TimeUnit.SECONDS)
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    @Volatile private var ws: WebSocket? = null
    @Volatile private var stopped = false
    @Volatile var online = false
        private set
    private var attempt = 0
    private var lastProblem = ""
    private var reconnectJob: Job? = null
    private val streams = ConcurrentHashMap<String, Channel<ServerMsg>>()

    fun start() {
        stopped = false
        connect()
    }

    fun stop() {
        stopped = true
        reconnectJob?.cancel()
        Safe.exec("ws.stop") { ws?.close(1000, "bye") }
        setOnline(false)
        failStreams()
    }

    /** Call when connectivity returns. */
    fun reconnectNow() {
        if (stopped || online) return
        reconnectJob?.cancel()
        attempt = 0
        connect()
    }

    @Synchronized
    private fun connect() {
        if (stopped) return
        Safe.exec("ws.connect") {
            ws?.cancel()
            ws = client.newWebSocket(Request.Builder().url(url).build(), Listener())
        }
    }

    fun openStream(id: String): Channel<ServerMsg> =
        Channel<ServerMsg>(Channel.UNLIMITED).also { streams[id] = it }

    fun closeStream(id: String) {
        streams.remove(id)?.close()
    }

    fun send(json: JSONObject): Boolean = Safe.call("ws.send", false) { ws?.send(json.toString()) == true }

    fun cancel(id: String) {
        send(JSONObject().put("type", "cancel").put("id", id))
    }

    private fun setOnline(v: Boolean) {
        if (online == v) return
        online = v
        if (v) lastProblem = ""
        Safe.exec("ws.state") { onState(v) }
    }

    private fun problem(msg: String) {
        if (msg == lastProblem) return
        lastProblem = msg
        Safe.exec("ws.problem") { onProblem(msg) }
    }

    private fun failStreams() {
        val all = streams.values.toList()
        streams.clear()
        all.forEach { it.close() }
    }

    private fun dropped(w: WebSocket) {
        if (w !== ws) return
        setOnline(false)
        failStreams()
        if (stopped) return
        reconnectJob?.cancel()
        val wait = min(30_000L, 500L shl min(attempt, 6)) + Random.nextLong(0, 400)
        attempt++
        reconnectJob = scope.launch {
            delay(wait)
            connect()
        }
    }

    private inner class Listener : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            if (webSocket !== ws) return
            Safe.exec("ws.auth") {
                webSocket.send(
                    JSONObject().put("type", "auth").put("token", token).put("session", session).put("v", 1).toString()
                )
            }
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            if (webSocket !== ws) return
            Safe.exec("ws.message") {
                val j = JSONObject(text)
                val type = j.optString("type")
                when (type) {
                    "ready" -> {
                        attempt = 0
                        setOnline(true)
                    }
                    "pong" -> {}
                    else -> {
                        val id = j.optString("id")
                        if (type == "error" && id.isEmpty()) {
                            problem("Server ne mana kiya: " + j.optString("message", "error"))
                        } else {
                            streams[id]?.trySend(ServerMsg(type, id, j))
                        }
                    }
                }
            }
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            Safe.exec("ws.closing") { webSocket.close(1000, null) }
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) = dropped(webSocket)

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            CrashLog.write("ws.failure", t, "${t.javaClass.simpleName}: ${t.message}")
            if (webSocket === ws) problem("Brain tak nahi pahunchi (${t.javaClass.simpleName}). URL, token aur firewall check karo.")
            dropped(webSocket)
        }
    }
}
