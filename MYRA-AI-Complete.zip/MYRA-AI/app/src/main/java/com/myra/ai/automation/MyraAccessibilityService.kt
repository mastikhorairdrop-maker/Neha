package com.myra.ai.automation

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * MYRA's hands: reads the screen, taps, types and scrolls on any app.
 * The rest of the app reaches it through [instance] (null while the service is off).
 */
class MyraAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: MyraAccessibilityService? = null
            private set
    }

    private val main = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---------- Read ----------

    /** Visible text / content descriptions on the current screen, joined with " | ". */
    fun readScreen(maxChars: Int = 600): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length >= maxChars) return
            if (n.isVisibleToUser) {
                val label = n.text?.toString()?.takeIf { it.isNotBlank() }
                    ?: n.contentDescription?.toString()?.takeIf { it.isNotBlank() }
                if (label != null) {
                    if (sb.isNotEmpty()) sb.append(" | ")
                    sb.append(label)
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return sb.toString().take(maxChars)
    }

    // ---------- Click ----------

    private fun clickableAncestor(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var cur = node
        while (cur != null && !cur.isClickable) cur = cur.parent
        return cur
    }

    private fun clickPass(root: AccessibilityNodeInfo, labels: List<String>, exact: Boolean): Boolean {
        for (label in labels) {
            for (n in root.findAccessibilityNodeInfosByText(label)) {
                if (exact) {
                    val hit = n.text?.toString().equals(label, ignoreCase = true) ||
                        n.contentDescription?.toString().equals(label, ignoreCase = true)
                    if (!hit) continue
                }
                val target = clickableAncestor(n)
                if (target != null && target.isEnabled && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true
                }
            }
        }
        return false
    }

    /** Exact label match first; with [loose] a substring match is tried second. */
    fun clickByText(labels: List<String>, loose: Boolean = false): Boolean {
        val root = rootInActiveWindow ?: return false
        return clickPass(root, labels, exact = true) || (loose && clickPass(root, labels, exact = false))
    }

    /** Polls until one of [labels] can be clicked (e.g. WhatsApp's Send button) or [timeoutMs] passes. */
    fun clickWhenAvailable(
        labels: List<String>,
        timeoutMs: Long = 8000L,
        intervalMs: Long = 400L,
        onResult: (Boolean) -> Unit
    ) {
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        val poll = object : Runnable {
            override fun run() {
                if (clickByText(labels)) {
                    onResult(true)
                } else if (SystemClock.uptimeMillis() >= deadline) {
                    onResult(false)
                } else {
                    main.postDelayed(this, intervalMs)
                }
            }
        }
        main.post(poll)
    }

    // ---------- Type ----------

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) findEditable(n.getChild(i))?.let { return it }
        return null
    }

    /** Appends [text] to the focused (or first) text field. */
    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        val existing = if (field.isShowingHintText) "" else field.text?.toString().orEmpty()
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, existing + text)
        }
        return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    // ---------- Scroll ----------

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) findScrollable(n.getChild(i))?.let { return it }
        return null
    }

    /** forward = content moves up (like "scroll down"). */
    fun scroll(forward: Boolean): Boolean {
        val target = findScrollable(rootInActiveWindow) ?: return false
        return target.performAction(
            if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    // ---------- System actions ----------

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun lockScreen(): Boolean =
        Build.VERSION.SDK_INT >= 28 && performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
}
