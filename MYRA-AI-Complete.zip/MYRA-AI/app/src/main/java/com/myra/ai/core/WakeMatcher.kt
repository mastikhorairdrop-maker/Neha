package com.myra.ai.core

import java.text.Normalizer

/** Spots "Okay Myra" (Roman or Devanagari, common mis-hearings included) in a transcript. */
object WakeMatcher {
    private val pattern = Regex(
        "(?:^|\\s)(?:ok|okay|o\\.k\\.|hey|hi|hello|ओके|ऑके|ओ के|हे|हेलो|हैलो)[\\s,]*" +
            "(?:my\\s*ra|myra|mira|meera|maira|mayra|मायरा|मीरा|माइरा|मैरा|मायेरा)(?=[\\s,.!?।]|$)",
        RegexOption.IGNORE_CASE
    )

    /** null = no wake phrase; otherwise whatever was said after it (possibly empty). */
    fun find(text: String): String? {
        val s = Normalizer.normalize(text, Normalizer.Form.NFC)
        val m = pattern.find(s) ?: return null
        return s.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?', '।')
    }
}
