package com.myra.ai

import android.app.AlarmManager
import android.app.Application
import android.app.PendingIntent
import android.content.Intent
import android.os.Looper
import android.os.Process
import com.myra.ai.core.CrashLog
import com.myra.ai.core.MyraEngine
import com.myra.ai.core.Safe
import kotlin.system.exitProcess

class MyraApp : Application() {

    /** Process-wide engine, shared by the UI and the wake-word service. */
    val engine: MyraEngine by lazy { MyraEngine(this).also { it.start() } }

    override fun onCreate() {
        super.onCreate()
        CrashLog.init(this)
        installCrashGuard()
        Safe.exec("app.engine") { engine }
    }

    /**
     * Last line of defence.
     * - Background-thread crash: logged and swallowed; the app keeps running.
     * - Main-thread crash: state may be corrupt, so log, schedule a relaunch (best effort) and exit cleanly
     *   instead of showing the system "keeps stopping" dialog.
     */
    private fun installCrashGuard() {
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            CrashLog.write("UNCAUGHT", throwable, "thread=${thread.name}")
            if (thread !== Looper.getMainLooper().thread) return@setDefaultUncaughtExceptionHandler
            try {
                val launch = packageManager.getLaunchIntentForPackage(packageName)
                    ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                if (launch != null) {
                    val pi = PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE)
                    (getSystemService(AlarmManager::class.java) as AlarmManager).set(AlarmManager.RTC, System.currentTimeMillis() + 1200, pi)
                }
            } catch (_: Throwable) {
            }
            Process.killProcess(Process.myPid())
            exitProcess(10)
        }
    }
}
