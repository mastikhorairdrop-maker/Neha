package com.myra.ai.core

import com.myra.ai.BuildConfig

/** Tweak MYRA's behaviour here. Backend URL/token come from gradle.properties. */
object MyraConfig {
    /** hi-IN returns Devanagari for Hindi words; the router understands both scripts. Try "en-IN" for Roman-only output. */
    const val SPEECH_LANG = "hi-IN"

    /** Prefix for 10-digit local numbers when opening WhatsApp chats. */
    const val DEFAULT_COUNTRY_CODE = "91"

    /** true = MYRA taps WhatsApp's Send button herself. false = she only opens the chat with text filled in. */
    const val WHATSAPP_AUTO_SEND = true

    /** Give up on a backend stream after this long with no message. */
    const val STREAM_IDLE_MS = 25_000L

    /** https://host from wss://host/ws (used for preview URLs). */
    val httpBase: String
        get() = BuildConfig.BACKEND_URL.replaceFirst("ws", "http").removeSuffix("/ws")
}
