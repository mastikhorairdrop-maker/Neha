package com.myra.ai.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * MYRA's avatar: glowing orb + radial waveform ring.
 * Feed it real audio with [setLevel] (0..1); THINKING / SPEAKING states self-animate.
 */
class OrbView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    var state: State = State.IDLE

    private val purple = Color.parseColor("#A855F7")
    private val red = Color.parseColor("#FF0055")
    private val cyan = Color.parseColor("#22D3EE")
    private val tau = (2 * PI).toFloat()

    private var externalLevel = 0f
    private var level = 0f
    private var phase = 0f

    private var cx = 0f
    private var cy = 0f
    private var baseR = 0f

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(60, 255, 255, 255) }
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = purple; alpha = 150 }
    private val ring2Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = red; alpha = 130 }
    private val ringRect = RectF()
    private val ring2Rect = RectF()

    private val animator: ValueAnimator = ValueAnimator.ofFloat(0f, 1f)

    init {
        animator.duration = 5000L
        animator.repeatCount = ValueAnimator.INFINITE
        animator.interpolator = LinearInterpolator()
        animator.addUpdateListener { anim ->
            phase = anim.animatedFraction
            val synthetic = when (state) {
                State.SPEAKING -> 0.45f + 0.3f * sin(phase * tau * 7f)
                State.THINKING -> 0.2f + 0.1f * sin(phase * tau * 3f)
                else -> 0f
            }
            val target = max(externalLevel, synthetic)
            level += (target - level) * 0.2f
            invalidate()
        }
    }

    fun setLevel(v: Float) {
        externalLevel = v.coerceIn(0f, 1f)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        cx = w / 2f
        cy = h / 2f
        baseR = min(w, h) * 0.24f
        if (baseR <= 0f) return

        glowPaint.shader = RadialGradient(
            cx, cy, baseR * 2.4f,
            intArrayOf(Color.parseColor("#99FF0055"), Color.parseColor("#33A855F7"), Color.TRANSPARENT),
            floatArrayOf(0.35f, 0.65f, 1f), Shader.TileMode.CLAMP
        )
        corePaint.shader = RadialGradient(
            cx - baseR * 0.3f, cy - baseR * 0.3f, baseR * 1.35f,
            intArrayOf(Color.parseColor("#F3E8FF"), purple, Color.parseColor("#4C0A8F"), Color.parseColor("#0A0A0C")),
            floatArrayOf(0f, 0.35f, 0.75f, 1f), Shader.TileMode.CLAMP
        )
        barPaint.shader = SweepGradient(cx, cy, intArrayOf(purple, red, cyan, purple), null)
        barPaint.strokeWidth = baseR * 0.035f
        val stroke = resources.displayMetrics.density * 1.5f
        ringPaint.strokeWidth = stroke
        ring2Paint.strokeWidth = stroke
        ringRect.set(cx - baseR * 1.18f, cy - baseR * 1.18f, cx + baseR * 1.18f, cy + baseR * 1.18f)
        ring2Rect.set(cx - baseR * 1.95f, cy - baseR * 1.95f, cx + baseR * 1.95f, cy + baseR * 1.95f)
    }

    override fun onDraw(canvas: Canvas) {
        if (baseR <= 0f) return
        val lv = level

        // 1. ambient glow
        val g = 1f + lv * 0.25f
        canvas.save()
        canvas.scale(g, g, cx, cy)
        canvas.drawCircle(cx, cy, baseR * 2.4f, glowPaint)
        canvas.restore()

        // 2. audio waveform ring
        val n = 72
        val inner = baseR * 1.32f
        for (i in 0 until n) {
            val ang = i / n.toFloat() * tau
            val wave = 0.5f + 0.5f * sin(ang * 5f + phase * tau * 3f)
            val len = baseR * (0.05f + 0.04f * wave + 0.55f * lv * wave)
            canvas.drawLine(
                cx + cos(ang) * inner, cy + sin(ang) * inner,
                cx + cos(ang) * (inner + len), cy + sin(ang) * (inner + len),
                barPaint
            )
        }

        // 3. rotating arcs
        canvas.save()
        canvas.rotate(phase * 360f, cx, cy)
        canvas.drawArc(ringRect, 0f, 100f, false, ringPaint)
        canvas.drawArc(ringRect, 180f, 100f, false, ringPaint)
        canvas.restore()
        canvas.save()
        canvas.rotate(-phase * 360f * 2f, cx, cy)
        canvas.drawArc(ring2Rect, 20f, 60f, false, ring2Paint)
        canvas.drawArc(ring2Rect, 200f, 60f, false, ring2Paint)
        canvas.restore()

        // 4. core
        val pulse = 1f + 0.03f * sin(phase * tau) + lv * 0.14f
        canvas.save()
        canvas.scale(pulse, pulse, cx, cy)
        canvas.drawCircle(cx, cy, baseR, corePaint)
        canvas.drawCircle(cx - baseR * 0.35f, cy - baseR * 0.4f, baseR * 0.22f, shinePaint)
        canvas.restore()
    }
}
