package com.myra.ai.ui

import android.graphics.Typeface
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.recyclerview.widget.RecyclerView
import com.myra.ai.R

/** Scrolling terminal feed. Lines with the same id are updated in place (used for streaming text/code). */
class LogAdapter : RecyclerView.Adapter<LogAdapter.VH>() {

    data class Line(val id: Long, val tag: String, val text: String, @ColorInt val color: Int)

    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    private val items = ArrayList<Line>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(
        LayoutInflater.from(parent.context).inflate(R.layout.item_log_line, parent, false) as TextView
    )

    override fun onBindViewHolder(holder: VH, position: Int) {
        val l = items[position]
        val tag = "[${l.tag}] "
        val s = SpannableString(tag + l.text)
        s.setSpan(ForegroundColorSpan(l.color), 0, tag.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(StyleSpan(Typeface.BOLD), 0, tag.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        holder.tv.text = s
    }

    override fun getItemCount() = items.size

    fun setAll(lines: List<Line>) {
        items.clear()
        items.addAll(lines)
        notifyDataSetChanged()
    }

    fun upsert(line: Line) {
        var i = items.size - 1
        while (i >= 0 && i >= items.size - 30) {
            if (items[i].id == line.id) {
                items[i] = line
                notifyItemChanged(i)
                return
            }
            i--
        }
        items.add(line)
        notifyItemInserted(items.size - 1)
        if (items.size > 300) {
            items.removeAt(0)
            notifyItemRemoved(0)
        }
    }
}
