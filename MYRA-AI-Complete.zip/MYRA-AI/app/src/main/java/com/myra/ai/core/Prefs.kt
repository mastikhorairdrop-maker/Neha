package com.myra.ai.core

import android.content.Context
import java.util.UUID

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("myra", Context.MODE_PRIVATE)

    fun wakeEnabled(c: Context): Boolean = Safe.call("prefs.wake", false) { sp(c).getBoolean("wake", false) }

    fun setWake(c: Context, v: Boolean) = Safe.exec("prefs.setWake") { sp(c).edit().putBoolean("wake", v).apply() }

    /** Stable id so the server can keep conversation memory across reconnects. */
    fun sessionId(c: Context): String = Safe.call("prefs.session", UUID.randomUUID().toString()) {
        sp(c).getString("session", null)
            ?: UUID.randomUUID().toString().also { sp(c).edit().putString("session", it).apply() }
    }
}
