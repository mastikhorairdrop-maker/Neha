# MYRA AI — Stage 3 (wake word + WebSocket brain + crash-safe core)

## 1. Start the backend
```bash
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                     # then edit .env
uvicorn main:app --host 0.0.0.0 --port 8000
```
In `.env` set:
- `MYRA_TOKEN` to a long random string (the server refuses to start without it).
- At least one key: `ANTHROPIC_API_KEY`, `GROQ_API_KEY`, `OPENAI_API_KEY`, `GEMINI_API_KEY`. Missing keys are skipped.
- Model IDs (`CLAUDE_MODEL` etc.) — provider model names change; if one is rejected MYRA logs it and falls back to the next provider.
- `CHAT_CHAIN` / `CODE_CHAIN` — fallback order. Default chat: groq → claude → openai → gemini (fast first). Default code: claude first.

Check it: open `http://localhost:8000/health` — it lists the providers that are live.
Tests: `python tests/test_codegen.py` (no deps) and `python tests/test_ws.py` (needs `pip install httpx`).

## 2. Point the app at it
Edit `gradle.properties` in the project root:
```
MYRA_BACKEND_URL=ws://10.0.2.2:8000/ws      # emulator
# MYRA_BACKEND_URL=ws://192.168.1.20:8000/ws  # real phone on the same Wi-Fi (your PC's LAN IP)
# MYRA_BACKEND_URL=wss://myra.example.com/ws  # deployed, behind HTTPS (required for release builds)
MYRA_TOKEN=<same value as backend/.env>
```
Debug builds allow plain `ws://`; release builds only allow `wss://`.

## 3. Build and run
Open the folder in Android Studio → Sync → Run on a device (Android 8.0+; Android 13+ recommended).

First-run checklist:
1. Flip **Hands-free: say "Okay Myra"** → allow Microphone and Notifications. A "MYRA is listening" notification appears (Android requires it).
2. Optional: say "lock kar do" → Activate Device Admin. Say "screen padho" → enable *MYRA Screen Automation* in Accessibility (Android 13+ sideloaded: App info → ⋮ → Allow restricted settings first).
3. Call / SMS / contacts permissions are requested the first time you use them.

## 4. Try it
- Wake word: "Okay Myra" → beep → speak. Or in one go: "Okay Myra, torch on karo".
- Local (instant, works offline): torch, battery, volume, alarm, timer, lock, call, SMS, WhatsApp, screen read/click/type/scroll.
- Brain (needs backend): anything else, e.g. "Okay Myra, quantum computing simple language mein samjhao".
- Builder: "Okay Myra, ek dark portfolio website banao" → files stream into the terminal, then the preview opens. The Code Builder card reopens the last one.
- Tap the orb any time to talk or to interrupt MYRA mid-sentence.

## 5. How it works
```
 mic ─► WakeWordService (foreground, microphone)         UI (MainActivity) = pure renderer
         WAKE → COMMAND → PAUSED                                  ▲ events
                    │ text                                        │
                    ▼                                             │
              MyraEngine (process-wide) ── CommandRouter ── device / WhatsApp / accessibility
                    │ not a local command
                    ▼
              MyraSocket (OkHttp WebSocket, auto-reconnect) ──► FastAPI /ws
                                                                   ├─ chat  → provider chain with fallback → tokens
                                                                   └─ build → file parser → /preview/<id>/index.html
```
Protocol (JSON frames): `auth` → `ready`; `ask{id,text}` → `mode`, `log`, `token`, `code_chunk`, `file_done`, `preview`, `done` | `error`; `cancel{id}`; `ping`/`pong`.

## 6. Stability measures
- Every callback (UI, service, socket, TTS, recognizer) is wrapped in `Safe.exec/call`; failures go to `files/myra.log` (rotating) instead of crashing.
- All I/O and parsing run on coroutines (`Dispatchers.IO/Default`); the main thread only renders. Supervisor scope: one failed task never cancels the others.
- Socket: exponential backoff with jitter, reconnect on network change, per-request channels, 25 s idle timeout, cancel on barge-in.
- Server: provider fallback before the first token (error, empty reply or >8 s), size limits, filename sanitising, sandboxed previews.
- Offline: local commands keep working with no server.
- Wake service: recognizer errors back off and restart, watchdog revives a stalled recognizer, on-device model falls back to the normal one, stuck PAUSED state self-heals.
- WebView render crashes are contained. Uncaught exceptions: background threads are logged and swallowed; a main-thread crash is logged, then the app exits quietly and tries to relaunch.

## 7. Honest limits
- **Wake word** uses Android's speech recognizer, not a dedicated wake-word engine: it costs battery, may need the network, and some devices beep on each restart. For an always-on production feel, swap in an on-device engine such as Picovoice Porcupine behind the same service.
- Android 14+ does not allow starting a microphone service from the background or at boot: open the app once after a reboot (the toggle is remembered).
- "Zero latency" doesn't exist; what you get is persistent connections, token streaming, sentence-by-sentence speech and local commands that never touch the network.
- Software can't promise "never crashes"; this makes failures contained, logged and self-recovering.
- Not compiled or run on a device in my environment. Expect to fix a small thing or two on first sync. The backend parser, filename safety and request detection are unit-tested; `test_ws.py` needs fastapi to run.
- Public deployment: add rate limiting/reverse proxy; the token in the APK is fine for personal use, not for a public app.

## 8. Troubleshooting
| Symptom | Fix |
|---|---|
| Pill says "Local mode" | Backend not running, wrong `MYRA_BACKEND_URL`, token mismatch, or phone can't reach the PC (firewall/port 8000) |
| "MYRA_TOKEN set nahi hai" in the log | Edit `gradle.properties`, then Sync |
| Hands-free toggle flips back off | Mic or notification permission denied, or the app wasn't in the foreground when starting |
| Wake word not caught | Say it slowly: "Okay Myra". Try `SPEECH_LANG = "en-IN"` in `MyraConfig.kt` |
| MYRA hears herself | Lower the media volume or use earphones |
| No spoken replies | Install/enable Google Text-to-Speech with Hindi voice data |
| Build says "all providers failed" | Check API keys and model IDs in `.env`; `/health` shows which providers loaded |
| Crash details | `adb shell run-as com.myra.ai cat files/myra.log` |
